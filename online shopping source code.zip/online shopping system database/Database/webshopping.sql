

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) CHARACTER SET gbk DEFAULT NULL,
  `username` varchar(255) CHARACTER SET gbk DEFAULT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('1', '123456', 'admin');

-- ----------------------------
-- Table structure for commodityclasses
-- ----------------------------
DROP TABLE IF EXISTS `commodityclasses`;
CREATE TABLE `commodityclasses` (
  `commodityClassId` int(11) NOT NULL AUTO_INCREMENT,
  `commodityClassName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`commodityClassId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;



-- ----------------------------
-- Table structure for commoditys
-- ----------------------------
DROP TABLE IF EXISTS `commoditys`;
CREATE TABLE `commoditys` (
  `commodityId` int(11) NOT NULL AUTO_INCREMENT,
  `commodityAmount` int(11) DEFAULT NULL,
  `commodityDepict` varchar(255) DEFAULT NULL,
  `commodityLeaveNum` int(11) DEFAULT NULL,
  `commodityName` varchar(255) DEFAULT NULL,
  `commodityPrice` double(10,0) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `webPrice` double(10,0) DEFAULT NULL,
  `commodityClass_commodityClassId` int(11) DEFAULT NULL,
  PRIMARY KEY (`commodityId`),
  KEY `FK4616CEE64542CEEB` (`commodityClass_commodityClassId`),
  CONSTRAINT `FK4616CEE64542CEEB` FOREIGN KEY (`commodityClass_commodityClassId`) REFERENCES `commodityclasses` (`commodityClassId`),
  CONSTRAINT `FKj4tautjpjuo1vbr4b3gpa758i` FOREIGN KEY (`commodityClass_commodityClassId`) REFERENCES `commodityclasses` (`commodityClassId`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messagetext` varchar(255) DEFAULT NULL,
  `messagetime` varchar(255) DEFAULT NULL,
  `messagetitle` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`messageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------

-- ----------------------------
-- Table structure for orderform
-- ----------------------------
DROP TABLE IF EXISTS `orderform`;
CREATE TABLE `orderform` (
  `orderFormID` int(25) NOT NULL AUTO_INCREMENT,
  `submitTime` varchar(50) DEFAULT NULL,
  `consignmentTime` varchar(50) DEFAULT NULL,
  `totalPrice` int(25) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `isPayoff` varchar(255) DEFAULT NULL,
  `isConsignment` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `orderFormNum` bigint(50) DEFAULT NULL,
  PRIMARY KEY (`orderFormID`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `post` varchar(255) DEFAULT NULL,
  `money` double DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;


