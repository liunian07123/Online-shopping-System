package cn.com.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.com.po.Commodity;
import cn.com.po.CommodityClass;
import cn.com.service.CommodityClassService;
import cn.com.service.CommodityService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
@Component("addToCarAction")
@Scope("prototype")
public class AddToCarAction extends ActionSupport {
	private CommodityService commodityService;
	private Commodity commodity;

	private Integer comamount;
	private double totalPrice=0;
	
	public CommodityService getCommodityService() {
		return commodityService;
	}
	@Resource
	public void setCommodityService(CommodityService commodityService) {
		this.commodityService = commodityService;
	}

	
	public void setCommodity(Commodity commodity) {
		this.commodity = commodity;
	}

	public Commodity getCommodity() {
		return commodity;
	}
	
	public void setComamount(Integer comamount) {
		this.comamount = comamount;
	}

	public Integer getComamount() {
		return comamount;
	}
	
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public double getTotalPrice() {
		return totalPrice;
	}
	
	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		
				
		int commodityId= commodity.getCommodityId();
		System.out.println("commodity id："+commodityId);
		Map session =(Map) ActionContext.getContext().getSession(); 
		
		Commodity commoditys = commodityService.findCommodityById(commodityId);
		if(commoditys.getCommodityLeaveNum()==0){
			ActionContext.getContext().getSession().put("comnull","out of commodity！");
			return "error";
		}
		else{
		System.out.println("test1");
						
		List<Commodity> car = null;	
		
		System.out.println("test2");
		if(session.get("car") == null) {	
			System.out.println("test3");
				car = new ArrayList<Commodity>();	
				
				car.add(commoditys);
				commoditys.setCommodityLeaveNum(commoditys.getCommodityLeaveNum()-1);
				commodityService.update(commoditys);
				System.out.println("car1:"+car.size());
		}
		else {
			System.out.println("test4");
			car = (List<Commodity>)session.get("car"); 
			
			System.out.println("test4.5");
				
				if(car.size()==0){  
					System.out.println("test4.6");	
					car.add(commoditys);
					commoditys.setCommodityLeaveNum(commoditys.getCommodityLeaveNum()-1);
					commodityService.update(commoditys);
					System.out.println("car2:"+car.size());
					
				}
				else{
					for(int i = car.size();i>0;i--){
						System.out.println("test4.7");
						
						Commodity com = car.get(i-1); //get commodity
						System.out.println("test4.8");
						if(com.getCommodityId() == commodityId) { //commodity already exist
							System.out.println("test5");
							System.out.println("car2:"+car.size());
						}
						else{		//commodity don't exist
							System.out.println("test5.1");	
							car.add(commoditys);//Add commodity to the shopping cart
							commoditys.setCommodityLeaveNum(commoditys.getCommodityLeaveNum()-1);
							commodityService.update(commoditys);
							System.out.println("car3:"+car.size());
						}
					}
				}
		}
		Iterator<Commodity>  it = car.iterator();
		for(int i = car.size();it.hasNext();i--){
			Commodity com = it.next();
				 totalPrice+=com.getCommodityPrice();      
		}
		
		System.out.println("test7");
		session.put("car", car);
		System.out.println("car:"+car.size());
		session.put("totalPrice", totalPrice);//
		System.out.println(totalPrice);
		return "success";
		}
	}
	
	@SuppressWarnings("unchecked")
	public String deleteFromCar(){
		
		int commodityId= commodity.getCommodityId();
		System.out.println("commodity id："+commodityId);
		
		Commodity commoditys = commodityService.findCommodityById(commodityId);
		commoditys.setCommodityLeaveNum(commoditys.getCommodityLeaveNum()+1);
		commodityService.update(commoditys);
		
		Map session = ActionContext.getContext().getSession();
		List<Commodity> car = (List<Commodity>)session.get("car");// get Shopping Cart
		Iterator<Commodity>  it = car.iterator();
		for(int i = car.size();it.hasNext();i--){
			Commodity com = it.next();
			if(com.getCommodityId() == commodityId) {
				 int index = car.indexOf(com); 
				 it.remove();        
			}
		}
		Iterator<Commodity>  is = car.iterator();
		for(int i = car.size();is.hasNext();i--){
			Commodity com = is.next();
				 totalPrice+=com.getCommodityPrice();      
		}
		session.put("car",car);
		System.out.println("car:"+car.size());
		return "delete";
	}
	
}
