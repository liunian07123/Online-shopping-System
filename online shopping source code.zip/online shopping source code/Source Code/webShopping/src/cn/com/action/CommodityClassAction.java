package cn.com.action;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.com.po.CommodityClass;
import cn.com.service.CommodityClassService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;



@SuppressWarnings("serial")
@Component("commodityClassAction")
@Scope("prototype")
public class CommodityClassAction extends ActionSupport {
	private CommodityClass commodityClass;
	
	
	@Resource(name="commodityClassServiceImpl")
	CommodityClassService service;
	public CommodityClassService getService() {
		return service;
	}

	public void setService(CommodityClassService service) {
		this.service = service;
	}

	public CommodityClass getCommodityClass() {
		return commodityClass;
	}

	public void setCommodityClass(CommodityClass commodityClass) {
		this.commodityClass = commodityClass;
	}
	
	@SuppressWarnings("unchecked")
	public String listCommodityClass(){
		Map request = (Map) ActionContext.getContext().get("request");
		
		request.put("listCommodityClasses", service.findAllCommodityClasses());
		System.out.println("listCommodityClasses");
		return "listCommodityClass";
	}
	public String deleteCommodityClass(){
		System.out.println(commodityClass.getCommodityClassName());
		this.service.delete(commodityClass);
		return "deleteCommodityClass";
	}
	public String findCommodityClassById(){
		commodityClass = this.service.findCommodityClassById(commodityClass.getCommodityClassId());
		return "findCommodityClass";
	}
	public String updateCommodityClass(){
		this.service.update(commodityClass);
		return "updateCommodityClass";
	}
	public String inputCommodityClass(){
		return "input";
	}
	//add commodity category
	@SuppressWarnings("unchecked")
	public String addCommodityClass(){
		//query if this commodity category exist
		CommodityClass commclass=this.service.findCommodityClassBName(commodityClass.getCommodityClassName());
		System.out.println("commclass:"+commclass);
		if(commclass==null){
		this.service.save(this.commodityClass);
		System.out.println("commodityClass:"+commodityClass.getCommodityClassName());
		ActionContext.getContext().put("message", commodityClass.getCommodityClassName()+"add successfully");
		}
		else ActionContext.getContext().put("message", "commodity category："+commodityClass.getCommodityClassName()+"already exist,please type information again！");
		return "addCommodityClass";
	}

	
	
}
