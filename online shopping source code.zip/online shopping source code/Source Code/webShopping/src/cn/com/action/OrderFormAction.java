package cn.com.action;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.com.action.*;
import cn.com.po.Commodity;
import cn.com.po.OrderForm;
import cn.com.po.User;
import cn.com.service.OrderFormService;
import cn.com.service.UserService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
@Component("orderFormAction")
@Scope("prototype")
public class OrderFormAction extends ActionSupport {
	private OrderForm orderForm;
	

	@Resource(name="orderFormServiceImpl")
	OrderFormService service;
	
	private UserService userservice;
	
	public OrderFormService getService() {
		return service;
	}

	public void setService(OrderFormService service) {
		this.service = service;
	}

	public OrderForm getOrderForm() {
		return orderForm;
	}

	public void setOrderForm(OrderForm orderForm) {
		this.orderForm = orderForm;
	}
	

	@Resource
	public void setUserservice(UserService userservice) {
		this.userservice = userservice;
	}


	public UserService getUserservice() {
		return userservice;
	}

	@Override
	public String execute() throws Exception {
		
			this.service.save(this.orderForm);
			System.out.println("orderForm:"+orderForm.getUsername());
			ActionContext.getContext().put("ordermessage", "Your order has submit！");
			return "success";
	}
	//List
	@SuppressWarnings("unchecked")
	public String listOrderForm(){
		Map request = (Map) ActionContext.getContext().get("request");
		
		request.put("listOrderForms", service.findAllOrderForms());
		System.out.println("listOrderForms");
		return "listOrderForm";
	}
	//query
	@SuppressWarnings("unchecked")
	public String queryOrderForm(){
		int orderFormId= orderForm.getOrderFormId();
		System.out.println("orderFormId:"+orderFormId);
		String username= orderForm.getUsername();
		System.out.println("username:"+username);
		String submitTime= orderForm.getSubmitTime();
		System.out.println("submitTime:"+submitTime);
		String consignmentTime= orderForm.getConsignmentTime();
		System.out.println("consignmentTime:"+consignmentTime);
	
		OrderForm orderForm=this.service.queryOrderForm(orderFormId);
		Map request=(Map) ActionContext.getContext().get("request");
		
		request.put("queryOrder", orderForm);
		return "queryOrder";
	}
	

	public String deleteOrderForm(){
		this.service.delete(orderForm);
		return "deleteOrderForm";
	}
	public String findOrderFormById(){
		orderForm = this.service.findOrderFormById(orderForm.getOrderFormId());
		return "findOrderForm";
	}
	//payment
	@SuppressWarnings("unchecked")
	public String payOrderForm(){
		double totalprice=orderForm.getTotalPrice();//total price of order
		User user=userservice.findUserByName(orderForm.getUsername());
		double money=user.getMoney();//all money of user
		Map request = (Map) ActionContext.getContext().get("request");
		if(totalprice>money){
			orderForm.setIsPayoff("No");
			request.put("nowOrder", orderForm);
			ActionContext.getContext().put("payemessage", "Your balance is not enough！");
		}
		else
		{
		user.setMoney(money-totalprice);
		userservice.update(user);
		orderForm.setIsPayoff("Yes");
		this.service.update(orderForm);
		
		System.out.println("orderForm:"+orderForm.getOrderFormId());
		
		request.put("nowOrder", orderForm);
		ActionContext.getContext().put("payemessage", "Successful payment！");
		}
		return "payOrderForm";
	}
	
	//Order list payment
	@SuppressWarnings("unchecked")
	public String payOrder(){
		double totalprice=orderForm.getTotalPrice();//total price of order
		String username=orderForm.getUsername();
		User user=userservice.findUserByName(orderForm.getUsername());
		double money=user.getMoney();//All money of user
		
		Map request = (Map) ActionContext.getContext().get("request");
		
		if(totalprice>money){
			orderForm.setIsPayoff("No");
			request.put("orderFormByUserName", service.findOrderFormByUserName(username));
			ActionContext.getContext().put("payemessage", "Your balance is not enough！");
		}
		else
		{
		user.setMoney(money-totalprice);
		userservice.update(user);
		orderForm.setIsPayoff("Yes");
		this.service.update(orderForm);
		System.out.println("orderForm:"+orderForm.getOrderFormId());
		
		request.put("orderFormByUserName", service.findOrderFormByUserName(username));
		ActionContext.getContext().put("payemessage", "Successful payment！");
		}
		return "payOrder";
	}
	
	public String inputOrderForm(){
		return "input";
	}
	//delivery
	@SuppressWarnings("unchecked")
	public String conOrder(){
		orderForm.setIsConsignment("Yes");
		this.service.update(orderForm);
		Map request = (Map) ActionContext.getContext().get("request");
		request.put("listOrderForms", service.findAllOrderForms());
		
		return "conOrder";
	}
	//submit order
	@SuppressWarnings("unchecked")
	public String addOrderForm(){
		this.service.save(this.orderForm);
		
		Map session = ActionContext.getContext().getSession();
		List<Commodity> car = (List<Commodity>)session.get("car");
		car.clear();
		
		Map request = (Map) ActionContext.getContext().get("request");
		request.put("nowOrder",orderForm);
		return "addOrderForm";
	}
	
	@SuppressWarnings("unchecked")
	public String findOrderFormByUserName(){
		Map request = (Map) ActionContext.getContext().get("request");
		
		request.put("orderFormByUserName",this.service.findOrderFormByUserName(orderForm.getUsername()));
		return "findOrderFormByUserName";
	}
	
}
