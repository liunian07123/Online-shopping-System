package cn.com.action;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.mapping.List;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.com.po.Message;
import cn.com.service.MessageService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
@Component("messageAction")
@Scope("prototype")
public class MessageAction extends ActionSupport {
	private Message message;
	

	@Resource(name="messageServiceImpl")
	MessageService service;
	public MessageService getService() {
		return service;
	}

	public void setService(MessageService service) {
		this.service = service;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	

	@Override
	public String execute() throws Exception {
		
			this.service.save(this.message);
			System.out.println("message:"+message.getUsername());
			ActionContext.getContext().put("tijiaomessage", "Your message has submit！");
			return "success";
	}
	
	@SuppressWarnings("unchecked")
	public String listMessage(){
		Map request = (Map) ActionContext.getContext().get("request");
		
		request.put("listMessages", service.findAllMessages());
		System.out.println("listMessages");
		return "listMessage";
	}
	//query
	@SuppressWarnings("unchecked")
	public String queryMessage(){
		int messageId= message.getMessageId();
		System.out.println("messageId:"+messageId);
		String username= message.getUsername();
		System.out.println("username:"+username);
		String messagetitle= message.getMessagetitle();
		System.out.println("messagetitle:"+messagetitle);
		
		
		Message message=this.service.queryMessage(username);
		System.out.println("message:"+message);
		Map request = (Map) ActionContext.getContext().get("request");
		
		request.put("queryMessage", message);

		return "queryMessage";
	}
	
	public String deleteMessage(){
		this.service.delete(message);
		return "deleteMessage";
	}
	public String findMessageById(){
		message = this.service.findMessageById(message.getMessageId());
		return "findMessage";
	}
	
		
	@SuppressWarnings("unchecked")
	public String addMessage(){
		this.service.save(this.message);
		Map request = (Map) ActionContext.getContext().get("request");
		
		return "addmessage";
	}

}
