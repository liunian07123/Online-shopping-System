package cn.com.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.com.po.Commodity;
import cn.com.po.CommodityClass;
import cn.com.service.CommodityClassService;
import cn.com.service.CommodityService;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
@Component("goIndexAction")
@Scope("prototype")
public class GoIndexAction extends ActionSupport {
	private CommodityClassService commodityClassService;
	private List<CommodityClass> commodityClasses;// Commodity list


	public CommodityClassService getCommodityClassService() {
		return commodityClassService;
	}

	@Resource
	public void setCommodityClassService(
			CommodityClassService commodityClassService) {
		this.commodityClassService = commodityClassService;
	}

	public List<CommodityClass> getCommodityClasses() {
		return commodityClasses;
	}


	public void setCommodityClasses(List<CommodityClass> commodityClasses) {
		this.commodityClasses = commodityClasses;
	}

	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		Map request = (Map) ActionContext.getContext().get("request");

		commodityClasses = commodityClassService.findAllCommodityClasses();// query all category of commodity
		request.put("listCommodityClasses", commodityClasses);
		
		System.out.println(commodityClasses);
				
		return "success";
	}
}
