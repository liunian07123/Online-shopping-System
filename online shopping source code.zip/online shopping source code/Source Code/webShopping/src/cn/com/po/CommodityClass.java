package cn.com.po;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="commodityClasses")//table name
public class CommodityClass implements java.io.Serializable {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)  
	private Integer commodityClassId;		
	private String commodityClassName;		

	public Integer getCommodityClassId() {
		return this.commodityClassId;
	}

	public void setCommodityClassId(Integer commodityClassId) {
		this.commodityClassId = commodityClassId;
	}

	public String getCommodityClassName() {
		return this.commodityClassName;
	}

	public void setCommodityClassName(String commodityClassName) {
		this.commodityClassName = commodityClassName;
	}

	public CommodityClass(Integer commodityClassId) {
		super();
		this.commodityClassId = commodityClassId;
	}

	public CommodityClass() {
		super();
	}
}