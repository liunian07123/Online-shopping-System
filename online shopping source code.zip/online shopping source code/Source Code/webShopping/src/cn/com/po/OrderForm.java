package cn.com.po;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="orderform")//table name
public class OrderForm implements java.io.Serializable {
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)  
	private Integer orderFormId;	//order id
	private String username;		//account name
	
	private String submitTime;		//submit time
	private String consignmentTime;	//consignment time
	private Double totalPrice;		//total price
	private String remark;			//user remark
	
	private String isPayoff;		//payment or not
	private String isConsignment;	//consignment or not
	private Long orderFormNum;	//order form number
	
	public OrderForm()
	{}

	public OrderForm(String username, String submitTime,
			String consignmentTime, Double totalPrice, String remark,
			 String isPayoff, String isConsignment,Long orderFormNum) {
		this.username = username;
		this.submitTime = submitTime;
		this.consignmentTime = consignmentTime;
		this.totalPrice = totalPrice;
		this.remark = remark;
		
		this.isPayoff = isPayoff;
		this.isConsignment = isConsignment;
		this.setOrderFormNum(orderFormNum);
	}
	
	public Integer getOrderFormId() {
		return this.orderFormId;
	}

	public void setOrderFormId(Integer orderFormId) {
		this.orderFormId = orderFormId;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	
	public String getSubmitTime() {
		return this.submitTime;
	}

	public void setSubmitTime(String submitTime) {
		this.submitTime = submitTime;
	}

	public String getConsignmentTime() {
		return this.consignmentTime;
	}

	public void setConsignmentTime(String consignmentTime) {
		this.consignmentTime = consignmentTime;
	}

	public Double getTotalPrice() {
		return this.totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsPayoff() {
		return this.isPayoff;
	}

	public void setIsPayoff(String isPayoff) {
		this.isPayoff = isPayoff;
	}

	public String getIsConsignment() {
		return this.isConsignment;
	}

	public void setIsConsignment(String isConsignment) {
		this.isConsignment = isConsignment;
	}

	public void setOrderFormNum(Long orderFormNum) {
		this.orderFormNum = orderFormNum;
	}

	public Long getOrderFormNum() {
		return orderFormNum;
	}

}