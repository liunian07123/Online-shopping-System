package cn.com.po;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity 
@Table(name="commoditys")
public class Commodity implements java.io.Serializable {
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)  
	private Integer commodityId;			
	
	@ManyToOne(cascade=CascadeType.MERGE)
	private CommodityClass commodityClass;
	
	private String commodityName;			
	private String manufacturer;			
	private String commodityDepict;			
	private Double commodityPrice;			
	private Double webPrice;				
	private Integer commodityAmount;		
	private Integer commodityLeaveNum;		
	private String image;					

	public Commodity() {
	}

	public Commodity(CommodityClass commodityClass, String commodityName,
			String manufacturer, String commodityDepict, Double commodityPrice,
			Double webPrice, Integer commodityAmount, Integer commodityLeaveNum,
			String image) {
		this.commodityClass = commodityClass;
		this.commodityName = commodityName;
		this.manufacturer = manufacturer;
		this.commodityDepict = commodityDepict;
		this.commodityPrice = commodityPrice;
		this.webPrice = webPrice;
		this.commodityAmount = commodityAmount;
		this.commodityLeaveNum = commodityLeaveNum;
		
		this.image = image;
	}

	public Integer getCommodityId() {
		return this.commodityId;
	}

	public void setCommodityId(Integer commodityId) {
		this.commodityId = commodityId;
	}

	public CommodityClass getCommodityClass() {
		return this.commodityClass;
	}

	public void setCommodityClass(CommodityClass commodityClass) {
		this.commodityClass = commodityClass;
	}

	public String getCommodityName() {
		return this.commodityName;
	}

	public void setCommodityName(String commodityName) {
		this.commodityName = commodityName;
	}

	public String getManufacturer() {
		return this.manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getCommodityDepict() {
		return this.commodityDepict;
	}

	public void setCommodityDepict(String commodityDepict) {
		this.commodityDepict = commodityDepict;
	}

	public Double getCommodityPrice() {
		return this.commodityPrice;
	}

	public void setCommodityPrice(Double commodityPrice) {
		this.commodityPrice = commodityPrice;
	}

	public Double getWebPrice() {
		return this.webPrice;
	}

	public void setWebPrice(Double webPrice) {
		this.webPrice = webPrice;
	}

	public Integer getCommodityAmount() {
		return this.commodityAmount;
	}

	public void setCommodityAmount(Integer commodityAmount) {
		this.commodityAmount = commodityAmount;
	}

	public Integer getCommodityLeaveNum() {
		return this.commodityLeaveNum;
	}

	public void setCommodityLeaveNum(Integer commodityLeaveNum) {
		this.commodityLeaveNum = commodityLeaveNum;
	}



	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}