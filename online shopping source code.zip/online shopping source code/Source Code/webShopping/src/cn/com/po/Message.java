package cn.com.po;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="message")//table name
public class Message implements java.io.Serializable {
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)  
	private Integer messageId;	//message id
	private String username;	//account name
	
	private String messagetitle;		//message title
	private String messagetime;	//message time
	private String messagetext;//message text
	
	public Message(){
		
	}
	public Message(Integer messageId, String username, String messagetitle,
			String messagetime, String messagetext) {
		super();
		this.messageId = messageId;
		this.username = username;
		this.messagetitle = messagetitle;
		this.messagetime = messagetime;
		this.messagetext = messagetext;
	}

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMessagetitle() {
		return messagetitle;
	}

	public void setMessagetitle(String messagetitle) {
		this.messagetitle = messagetitle;
	}

	public String getMessagetime() {
		return messagetime;
	}

	public void setMessagetime(String messagetime) {
		this.messagetime = messagetime;
	}

	public String getMessagetext() {
		return messagetext;
	}

	public void setMessagetext(String messagetext) {
		this.messagetext = messagetext;
	}

	
}