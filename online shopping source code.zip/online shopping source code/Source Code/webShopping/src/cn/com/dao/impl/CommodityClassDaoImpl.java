package cn.com.dao.impl;

import java.util.List;

import javax.annotation.Resource;




import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import cn.com.dao.CommodityClassDao;
import cn.com.po.Admin;
import cn.com.po.Commodity;
import cn.com.po.CommodityClass;

@Component("commodityClassDaoImpl")
public class CommodityClassDaoImpl implements CommodityClassDao {

	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	public void delete(CommodityClass commodityClass) {
	hibernateTemplate.delete(commodityClass);
	}
	@SuppressWarnings("unchecked")
	public List<CommodityClass> findAllCommodityClasses() {
		String hql = "from CommodityClass";
		return (List<CommodityClass>)hibernateTemplate.find(hql);
	}

	public CommodityClass findCommodityClassById(int id) {
		CommodityClass commodityClass = (CommodityClass)hibernateTemplate.get(CommodityClass.class, id);
		return commodityClass;
	}
	
	public CommodityClass findCommodityClassBName(String name){
		
	return  (CommodityClass) hibernateTemplate.getSessionFactory().openSession().createQuery(
	"from CommodityClass c where c.commodityClassName=? ").setParameter(0, name).uniqueResult();
	}
	
	public CommodityClass findCommodityClassByName(String name) {
		System.out.println("findbyname:"+name);
		CommodityClass commodityClass = (CommodityClass)hibernateTemplate.get(CommodityClass.class, name);
		System.out.println("commodityClass:"+commodityClass);
		return commodityClass;
	
	}
	
	public void save(CommodityClass CommodityClass) {
		System.out.println(CommodityClass);
	 hibernateTemplate.save(CommodityClass);
	}

	public void update(CommodityClass CommodityClass) {
	hibernateTemplate.update(CommodityClass);

	}
	public HibernateTemplate getHibernateTmeplate() {
		return hibernateTemplate;
	}
	public void setHibernateTmeplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	

}
