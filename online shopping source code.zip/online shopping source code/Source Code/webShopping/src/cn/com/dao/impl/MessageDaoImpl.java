package cn.com.dao.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;




import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import cn.com.dao.MessageDao;
import cn.com.po.Message;

@Component("messageDaoImpl")
public class MessageDaoImpl implements MessageDao {

	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	public void delete(Message message) {
	hibernateTemplate.delete(message);
	}
	@SuppressWarnings("unchecked")
	public List<Message> findAllMessages() {
		String hql = "from Message";
		return (List<Message>)hibernateTemplate.find(hql);
	}

	public Message findMessageById(int id) {
		Message message = (Message)hibernateTemplate.get(Message.class, id);
		return message;
	}

	public void save(Message message) {
		System.out.println(message);
	 hibernateTemplate.save(message);
	}

	public HibernateTemplate getHibernateTmeplate() {
		return hibernateTemplate;
	}
	public void setHibernateTmeplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	public Message queryMessage(String username) {
		
		return (Message)hibernateTemplate.getSessionFactory().openSession().createQuery(
		"from Message m where m.username=? ").setParameter(
				0, username).uniqueResult();

	}
	
}
