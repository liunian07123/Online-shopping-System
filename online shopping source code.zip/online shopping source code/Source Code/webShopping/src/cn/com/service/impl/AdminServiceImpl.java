package cn.com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.com.dao.AdminDao;
import cn.com.po.Admin;
import cn.com.service.AdminService;

@Component("adminServiceImpl")
public class AdminServiceImpl implements AdminService {
	
	@Resource(name="adminDaoImpl")
	private AdminDao adminDao;
	public AdminDao getUserDao() {
		return adminDao;
	}

	public void setUserDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public void delete(Admin user) {
		this.adminDao.delete(user);

	}
	public List<Admin> findAllAdmins() {
		return this.adminDao.findAllAdmins();
	}
	public Admin findAdminById(int id) {
		// TODO Auto-generated method stub
		return this.adminDao.findAdminById(id);
	}

	public void save(Admin admin) {
		this.adminDao.save(admin);

	}

	public void update(Admin admin) {
		this.adminDao.update(admin);
	}


	public Admin getUserByLoginNameAndPassword(String name, String password) {
		
		return this.adminDao.getUserByLoginNameAndPassword(name,password);
	}


}
