package cn.com.service;

import java.util.Date;
import java.util.List;

import cn.com.po.Message;

public interface MessageService {

	public void save(Message message);
	public void delete(Message message);
	public Message findMessageById(int id);
	public List<Message> findAllMessages();
	public Message queryMessage(String username);
	
}
