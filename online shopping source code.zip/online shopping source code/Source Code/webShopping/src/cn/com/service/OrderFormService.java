package cn.com.service;

import java.util.List;

import cn.com.po.OrderForm;

public interface OrderFormService {

	public void save(OrderForm user);
	public void delete(OrderForm id);
	public OrderForm findOrderFormById(int id);
	public List<OrderForm> findAllOrderForms();
	public void update(OrderForm orderForm);
	public OrderForm queryOrderForm(int orderFormId);
	public List<OrderForm> findOrderFormByUserName(String username); 
	
}
