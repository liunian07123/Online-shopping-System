package cn.com.service;

import java.util.List;
import java.util.Map;

import cn.com.po.User;

public interface UserService {

	public void save(User user);
	public void delete(User id);
	public User findUserById(int id);
	public List<User> findAllUsers();
	public void update(User user); 
	//public void initPassword(User user);
	public User getUserByLoginNameAndPassword(String username, String password);
	public User findUserByName(String username);
	public User queryUser(String username);
	public User findUserByinfo(String username, String name, String sex,
			String phone, String post, String address, String email);
}
