package cn.com.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.com.dao.MessageDao;
import cn.com.po.Message;
import cn.com.service.MessageService;


@Component("messageServiceImpl")
public class MessageServiceImpl implements MessageService {
	
	@Resource(name="messageDaoImpl")
	private MessageDao messageDao;
	public MessageDao getMessageDao() {
		return messageDao;
	}

	public void setMessageDao(MessageDao messageDao) {
		this.messageDao = messageDao;
	}

	public void delete(Message message) {
		this.messageDao.delete(message);

	}
	public List<Message> findAllMessages() {
		return this.messageDao.findAllMessages();
	}
	public Message findMessageById(int id) {
		
		return this.messageDao.findMessageById(id);
	}

	public void save(Message message) {
		this.messageDao.save(message);
		
	}

	public Message queryMessage(String username) {

		return this.messageDao.queryMessage(username);
	}

}
