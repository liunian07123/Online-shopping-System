package cn.com.service.impl;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.com.dao.CommodityClassDao;
import cn.com.po.CommodityClass;
import cn.com.service.CommodityClassService;


@Component("commodityClassServiceImpl")
public class CommodityClassServiceImpl implements CommodityClassService {

		
		@Resource(name="commodityClassDaoImpl")
		private CommodityClassDao commodityClassDao;
		public CommodityClassDao getUserDao() {
			return commodityClassDao;
		}

		public void setUserDao(CommodityClassDao commodityClassDao) {
			this.commodityClassDao = commodityClassDao;
		}

		public void delete(CommodityClass commodityClass) {
			this.commodityClassDao.delete(commodityClass);

		}
		public List<CommodityClass> findAllCommodityClasses() {
			return this.commodityClassDao.findAllCommodityClasses();
		}
		public CommodityClass findCommodityClassById(int id) {
			
			return this.commodityClassDao.findCommodityClassById(id);
		}

		public void save(CommodityClass commodityClass) {
			this.commodityClassDao.save(commodityClass);

		}

		public void update(CommodityClass commodityClass) {
			this.commodityClassDao.update(commodityClass);
		}

		public CommodityClass findCommodityClassByName(String name) {
			return this.commodityClassDao.findCommodityClassByName(name);
		}
		public CommodityClass findCommodityClassBName(String name) {
			return this.commodityClassDao.findCommodityClassBName(name);
		}
	}

