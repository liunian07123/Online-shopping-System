package cn.com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.com.dao.CommodityDao;
import cn.com.po.Commodity;
import cn.com.po.CommodityClass;
import cn.com.service.CommodityService;


@Component("commodityServiceImpl")
public class CommodityServiceImpl implements CommodityService {
	
	@Resource(name="commodityDaoImpl")
	private CommodityDao commodityDao;
	public CommodityDao getCommodityDao() {
		return commodityDao;
	}

	public void setCommodityDao(CommodityDao commodityDao) {
		this.commodityDao = commodityDao;
	}

	public void delete(Commodity commodity) {
		this.commodityDao.delete(commodity);

	}
	public List<Commodity> findAllCommoditys() {
		return this.commodityDao.findAllCommoditys();
	}
	public Commodity findCommodityById(int id) {
		
		return this.commodityDao.findCommodityById(id);
	}

	public void save(Commodity commodity) {
		this.commodityDao.save(commodity);

	}

	public void update(Commodity commodity) {
		this.commodityDao.update(commodity);
	}
	
	public List<Commodity> findCommodityByName(String Name) {
		return this.commodityDao.findCommodityByName(Name);
	}

	public List<Commodity> findCommodityByClass(CommodityClass commodityclass) {
		
		return this.commodityDao.findCommodityByClass(commodityclass);
	}
	public List<Commodity> findCommodityBName(String Name) {
		return this.commodityDao.findCommodityBName(Name);
	}
}
